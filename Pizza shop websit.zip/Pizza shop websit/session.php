<?php
    $conn = mysqli_connect("localhost", "test", "test", "project");
    
    session_start();
    if (isset($_SESSION['login_username']))
    {
        $user_check = $_SESSION['login_username'];
    }
    else {
        $user_check = "";
    }

    $query = "SELECT username from register where username = '$user_check'";
    $ses_sql = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($ses_sql);
    if (isset($_SESSION['login_username']))
    {
        $login_session = $row['username'];
    }
    else {
        $login_session = "";
    }
?>
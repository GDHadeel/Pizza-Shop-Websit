<?php
    session_start();
    $user_check = $_SESSION['login_username'];
    ini_set('display_errors', 1);

    if(isset($_GET["username"]))
    {
        $link = mysqli_connect("localhost","test","test") or die(mysqli_error($link));
        mysqli_select_db($link, "project") or die(mysqli_error($link));
        mysqli_query($link, "DELETE FROM contact WHERE username='$_GET[username]'");
    } else{
        echo"error";
    }
?>
<script>
    window.location="table.php";
</script>